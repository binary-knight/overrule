# Measuring a sandbox you cannot launch from outside

`agentsec blast-radius` launches the probe itself for containers and for any
launcher you can spell as a command. An agent's own sandbox is different: it is
entered by the agent, on the agent's terms. You cannot wrap it from outside, so
you ask the agent to run the probe and you score what comes back.

```bash
# 1. put the probe somewhere the agent can reach
cp agentsec/probe/blast_probe.py /tmp/probe.py

# 2. ask the agent to run it, inside whatever sandbox mode you are measuring.
#    If the mode can write files, redirect to one; that is the reliable path:
<agent> --sandbox workspace-write "run: python3 /tmp/probe.py > /tmp/out.json"

#    If the mode is read-only, it cannot write, so take the JSON from the
#    transcript. Agents sometimes clip the final brace; `score` repairs that
#    and says so.
<agent> --sandbox read-only "run python3 /tmp/probe.py and paste its raw stdout"

# 3. score it, recording exactly how you got it
agentsec score /tmp/out.json \
  --label "vendor-agent 1.2.3 read-only" \
  --how "…the exact command, date, host…" \
  --redact
```

`--how` is not decoration. A measurement nobody can repeat is not evidence, and
the capture method is the part a reader cannot infer from the JSON.

## Reading the result fairly

A sandbox mode is a documented boundary, not a promise of total isolation.
Before calling anything a finding, read what the vendor says the mode does. If
the documentation says the agent "can inspect files", then the agent reading
`~/.ssh/config` is the design working as written, and the honest report is
"this is what the documented boundary includes in the blast radius", not "we
found a vulnerability".

Report anything that genuinely contradicts the documentation to the vendor
before publishing it.

## Two gotchas when capturing from an agent's transcript

**Ask for the whole object, not a tail.** A read-only sandbox cannot write a file, so the probe's JSON has to come back through the agent's reply. If you cap the output (`tail -c N`) you lose the *leading* keys and the result will not parse. Ask for the complete output from the first `{` to the last `}`. `agentsec score` repairs a missing closing brace and tells you it did, but it cannot invent a missing opening one.

**The control tests behave differently by mode.** `unix_control` needs a writable directory, so in a read-only sandbox it fails at `mkdtemp` and proves nothing on its own. `unix_control_nopath` needs no writable directory: it connects to a path that does not exist, where `FileNotFoundError` means unix-domain connect is permitted and `PermissionError` means the call was refused before the path was consulted. Scoring prefers the first control and falls back to the second, and says plainly when neither settled the question.

## Trap 1: the captured sandbox inherits the shell you launched it from

This one has now caught two people independently, both of whom had read this
document. It is the default outcome, not an unlucky one.

An agent's sandbox inherits the environment of whatever started it. Launch the
agent from inside another agent's shell, or from a terminal where you have
exported a token, and those variables are visible inside the sandbox and are
scored against the product you think you are measuring. The tell is a
secret-shaped variable in the report that has nothing to do with the vendor:
`CLAUDE_CODE_MESSAGING_TOKEN` and `CLOUDSDK_PROXY_PASSWORD` are both ones that
have shown up this way.

Prefer a plain terminal. Where you cannot, strip the environment and say that
you did:

```bash
env -i HOME="$HOME" PATH="$PATH" TERM=xterm USER="$USER" SHELL=/bin/bash LANG=C.UTF-8 \
  <agent command>
```

Measuring both ways is better than choosing one, and the difference is the part
of the blast radius you close by fixing your own shell rather than the agent.
Whichever you do, record it in `--how`.

## Minimise the launching environment, or say that you did not

An agent's sandbox inherits the environment of the shell that started it. Anything exported there is visible inside and is scored against the agent, which is misleading when the variable came from your terminal rather than the product. Launch with a minimal environment when you want the intrinsic figure:

```bash
env -i HOME="$HOME" PATH="$PATH" TERM=xterm USER="$USER" SHELL=/bin/bash LANG=C.UTF-8 \
  <agent command>
```

Measuring both ways is better than choosing one. The difference is the part of the blast radius you can close by fixing your own shell. Record which you did in `--how`; a score without its environment is not comparable to another score.

## When a launcher is installed and still cannot build a sandbox

`bwrap` on PATH does not mean bubblewrap can sandbox anything. Ubuntu 24.04 ships
with unprivileged user namespaces restricted, so bubblewrap gets `Permission
denied` setting up its uid map and the probe never runs. Check the capability
rather than the binary:

```bash
bwrap --ro-bind / / --unshare-user --unshare-pid --dev /dev --proc /proc true \
  && echo "can sandbox" || echo "cannot"

cat /proc/sys/kernel/apparmor_restrict_unprivileged_userns   # 1 means restricted
```

Two ways out. Where you control the host, allow it for this binary with an
AppArmor profile at `/etc/apparmor.d/bwrap` granting `userns,`, then
`sudo apparmor_parser -r /etc/apparmor.d/bwrap`. On a throwaway machine or a CI
runner, `sudo sysctl -w kernel.apparmor_restrict_unprivileged_userns=0` lifts it
globally, which is fine there and not fine on a workstation.

`agentsec` tests the capability rather than the path: `runner.sandbox_available()`
runs a trivial sandbox and reports whether it worked, and the test suite skips on
that rather than on `which`. Presence is not capability, which is the same point
the tool makes about everything else it measures.


## Trap 2: do not "improve" a score by moving what it looks at

`$HOME` is an environment variable, so anything inside a sandbox can set it.
Pointing it at an empty directory once cleared the credential finding and dropped
the score by fifteen points while every one of those files stayed readable at its
real path. That was a defect in this tool and it is fixed: credential paths are
now resolved under the passwd entry as well as `$HOME`, and each result records
which home found it in a `via` field.

The general rule survives the fix. **A number that falls because you moved the
instrument is not an improvement.** If a change lowers a score, be able to say
what it stopped the agent from reaching. If you cannot, you have concealed
something rather than contained it. Redirecting `$HOME` is a legitimate hardening
step and this tool does not score it against you; it simply will not let it hide
a file that is still reachable.

The same test applies to anything else you might be tempted to adjust: an
allowlist that removes a probe target, a label that reframes a finding, a budget
raised to meet a score. Contain the reach, or record the finding as accepted and
say why.
