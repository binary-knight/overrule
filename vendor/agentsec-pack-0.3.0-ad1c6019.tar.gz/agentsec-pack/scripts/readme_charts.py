#!/usr/bin/env python3
"""Regenerate the README's quick-look charts and table from the shipped reports.

    python scripts/readme_charts.py          # rewrite docs/img/*.svg and the table in README.md
    python scripts/readme_charts.py --check  # exit 1 if any of them is stale

Every row comes from a report JSON in examples/, so the chart cannot say
anything the reports do not. tests/test_chart.py runs --check.
"""
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from agentsec import chart  # noqa: E402

AGENTS = [
    ("Claude Code 2.1.266, no sandbox", "claude-code-2.1.266-default-no-sandbox"),
    ("Claude Code 2.1.266, sandbox on, socat missing", "claude-code-2.1.266-sandbox-enabled-deps-missing"),
    ("Claude Code 2.1.266, sandbox on", "claude-code-2.1.266-sandbox-enabled"),
    ("Claude Code 2.1.317, sandbox on, auto mode", "claude-code-2.1.317-sandbox-auto-mode"),
    ("Claude Code 2.1.317, github.com allowed", "claude-code-2.1.317-sandbox-auto-mode-github-allowed"),
    ("Claude Code 2.1.318, sandbox + denyRead", "claude-code-2.1.318-sandbox-denyread"),
    ("Codex CLI 0.153.4, read-only", "codex-cli-0.153.4-read-only"),
    ("Codex CLI 0.153.4, read-only, dev shell", "codex-cli-0.153.4-read-only-dev-shell"),
    ("Codex CLI 0.153.4, workspace-write", "codex-cli-0.153.4-workspace-write"),
    ("Codex CLI 0.153.4, workspace-write, dev shell", "codex-cli-0.153.4-workspace-write-dev-shell"),
    ("Codex CLI 0.164.0, read-only", "codex-cli-0.164.0-read-only"),
    ("Codex CLI 0.164.0, workspace-write", "codex-cli-0.164.0-workspace-write"),
    ("Antigravity CLI 1.4.12, --sandbox unavailable", "antigravity-cli-1.4.12-sandbox-unavailable"),
    ("Aider 0.86.2, ships no sandbox", "aider-0.86.2-default"),
]


# Rows whose network cell the report claims as sealed but the probe that took it could not
# settle: probe 0.1.0 never connected through an egress proxy, and Claude Code's sandbox
# routes egress through one. The README says to read these as unverified; the chart agrees.
NETWORK_UNVERIFIED = {"claude-code-2.1.266-sandbox-enabled"}


# The tasks scripts/select_harbor_sample.py drew that this machine could run.
# fp8-rmsnorm-gemm was also drawn and needs a GPU, so it has no report.
HARBOR_TASKS = ["fin-saccr-rwa", "formal-crypto", "interleaved-vigenere", "uefi-bootkit"]


def groups():
    agents = []
    for label, stem in AGENTS:
        row = chart.row_from_envelope(json.loads((ROOT / "examples/agents" / f"{stem}.json").read_text()), label)
        if stem in NETWORK_UNVERIFIED:
            row["cells"]["network"] = ("unmeasured", None)
        agents.append(row)
    matrix = json.loads((ROOT / "examples/matrix_slim.json").read_text())
    launchers = sorted(chart.rows_from_matrix(matrix), key=lambda r: -r["score"])
    load = lambda rel: json.loads((ROOT / rel).read_text())
    seatbelt = {r["label"]: r for r in chart.rows_from_matrix(load("examples/macos/seatbelt-presets.json"))}
    macos = [chart.row_from_envelope(load("examples/macos/no-sandbox.json"), "No sandbox"),
             seatbelt["seatbelt-allow-default"], seatbelt["seatbelt-deny-network"], seatbelt["seatbelt-confined"],
             chart.row_from_envelope(load("examples/agents/codex-cli-0.164.0-macos-sandbox-read-only.json"),
                                     "Codex CLI 0.164.0, read-only"),
             chart.row_from_envelope(load("examples/agents/codex-cli-0.164.0-macos-sandbox-workspace-write.json"),
                                     "Codex CLI 0.164.0, workspace-write"),
             chart.row_from_envelope(load("examples/agents/claude-code-2.1.318-macos-no-sandbox.json"),
                                     "Claude Code 2.1.318, no sandbox"),
             chart.row_from_envelope(load("examples/agents/claude-code-2.1.318-macos-sandbox.json"),
                                     "Claude Code 2.1.318, sandbox on"),
             chart.row_from_envelope(load("examples/agents/claude-code-2.1.318-macos-sandbox-denyread.json"),
                                     "Claude Code 2.1.318, sandbox + denyRead")]
    harbor = [chart.row_from_envelope(load(f"examples/harbor/harbor-{t}.json"), t) for t in HARBOR_TASKS]
    return agents, launchers, macos, harbor


def outputs():
    agents, launchers, macos, harbor = groups()
    out = {}
    for theme in ("light", "dark"):
        out[f"docs/img/agents-{theme}.svg"] = chart.render_svg(
            [("", agents)], "Coding agents' own sandboxes",
            "One row per measured configuration. Score 0 means the probe reached nothing.", theme)
        out[f"docs/img/launchers-{theme}.svg"] = chart.render_svg(
            [("", launchers)], "python:3.12-slim under eleven launchers",
            "Docker, Podman and bubblewrap configurations on one Linux host, probe 0.4.0.", theme)
        out[f"docs/img/macos-{theme}.svg"] = chart.render_svg(
            [("", macos)], "macOS: Seatbelt, Codex and Claude Code",
            "A GitHub-hosted macOS 26.6 machine, probe 0.6.0. Codex through codex sandbox, Claude Code in headless sessions.", theme)
    for theme in ("light", "dark"):
        out[f"docs/img/harbor-{theme}.svg"] = chart.render_svg(
            [("", harbor)], "Public Terminal-Bench tasks under Harbor",
            "Agent phase, Docker environment, a neutral sample of 66 tasks, one Linux host, probe 0.6.0.", theme)
    table = chart.render_markdown([("Coding agents' own sandboxes", agents), ("python:3.12-slim under eleven launchers", launchers),
                                   ("macOS: Seatbelt, Codex and Claude Code", macos),
                                   ("Public Terminal-Bench tasks under Harbor", harbor)])
    readme = (ROOT / "README.md").read_text()
    start, end = "<!-- results-table:start -->", "<!-- results-table:end -->"
    a, b = readme.index(start) + len(start), readme.index(end)
    out["README.md"] = readme[:a] + "\n<!-- generated by scripts/readme_charts.py from the reports in examples/ -->\n\n" + table + readme[b:]
    return out


def main(argv):
    stale = []
    for rel, content in outputs().items():
        path = ROOT / rel
        if "--check" in argv:
            if not path.exists() or path.read_text() != content:
                stale.append(rel)
            continue
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content)
        print("wrote", rel)
    if stale:
        print("stale, run scripts/readme_charts.py:", ", ".join(stale))
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
