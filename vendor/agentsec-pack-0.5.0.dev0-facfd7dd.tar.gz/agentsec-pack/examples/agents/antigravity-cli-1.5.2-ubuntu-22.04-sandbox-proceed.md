# Sandbox blast radius: antigravity-cli-1.5.2-ubuntu-22.04-sandbox-proceed

**Score: 31 / 100** (0 = fully contained; higher = larger blast radius)  
Findings: 4 (critical 0, high 1, medium 2, low 0)

## Target (reproduce with this)
- kind: `captured`
- label: `antigravity-cli-1.5.2-ubuntu-22.04-sandbox-proceed`
- how: `agy 1.5.2 -p --sandbox --settings {"toolPermission": "proceed-in-sandbox"} on ubuntu-22.04, with modelProvider gemini in settings.json. The model was a local stub reached through GOOGLE_GEMINI_BASE_URL, which asked for one shell command, /usr/bin/python3 probe.py | /usr/bin/python3 -c (compress and print it), and then stopped, so no real model or account was involved. Launched with only HOME, PATH, USER, TMPDIR, TERM, SHELL, LANG, the stub's address and a placeholder GEMINI_API_KEY, from a throwaway git repository holding empty project config directories, by scripts/measure_stubbed_agent.py on a disposable GitHub-hosted machine, whose home holds no personal credentials.`
- note: `Captured externally: the probe was run inside the target by the means described in `how`, not launched by agentsec.`
- probe version: `0.7.0`, python `3.10.12`, uid `1001`, seccomp `2`, user namespace `True`

## Findings
### NET-003 · INFO · No network reachable from the sandbox (containment holds)
- evidence: `{'detail': 'sockets can be created but every outbound connection and name lookup was refused'}`
- OWASP agentic: ASI02 Tool Misuse & Exploitation
- fix: No action: nothing the probe tried could leave this sandbox over the network.

### SEC-002 · HIGH · Secret-looking environment variables visible to the agent
- evidence: `{'names': ['<redacted>', '<redacted>']}`
- OWASP agentic: ASI03 Agent Identity & Privilege Abuse, ASI02 Tool Misuse & Exploitation
- fix: Inject secrets through a broker or scoped short-lived tokens; do not export them into the agent's environment.

### SEC-004 · MEDIUM · PID 1 environment readable (host or supervisor secrets exposed)
- OWASP agentic: ASI03 Agent Identity & Privilege Abuse
- fix: Run the agent in its own PID namespace.

### FS-003 · MEDIUM · Read-write bind mounts from the host
- evidence: `{'mounts': ['~/.cache', '~/.cargo', '~/.dotnet', '~/.gemini/antigravity-cli/brain/35d2382b-a59d-4888-80ba-fac3e576add5', '~/.nvm', '~/.rustup', '/sys/firmware/efi/efivars']}`
- OWASP agentic: ASI02 Tool Misuse & Exploitation, ASI05 Unexpected Code Execution
- fix: Mount only the working tree, read-only where possible; never mount the host root.

## Equivalent controls (written as the container engine flags; translate for your launcher)

This target is not a container, so the flags below are the docker/podman spelling of each control. Bubblewrap and other launchers express the same controls differently (`--unshare-net` for the network, `--seccomp` with a compiled filter, and so on).

A starting point, not a policy: each entry closes at least one finding observed here. Anything in parentheses is a change to how the sandbox is composed rather than a flag. A workload that genuinely needs the network or a dropped capability will break under these, and that is the operator's call to make deliberately.

```
(inject secrets through a broker, not the environment)
(own PID namespace: avoid --pid=host)
(mount the working tree only, :ro where possible)
```

## What the probe does not do
It never reads secret values: readability is proven by opening a file and reading zero bytes. It sends no data to the egress targets; when an egress proxy is configured it sends that proxy one CONNECT request per fixed target and a control host, reads the status line and closes, and uses the proxy's password only when AGENTSEC_PROBE_PROXY_AUTH=1, never recording it. Its only writes are zero-byte markers, one per probed directory, each removed at once; existing startup and agent-settings files are opened for append and closed without writing, so nothing in them changes. Read `agentsec/probe/blast_probe.py` before running it in an environment you care about.
